/**
 * Automatically generated file. DO NOT MODIFY
 */
package org.ftc.shooter.tuner.library;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "org.ftc.shooter.tuner.library";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION = "0.1.7";
}
